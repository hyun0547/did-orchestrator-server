require("@nomicfoundation/hardhat-toolbox");
require("@nomicfoundation/hardhat-ethers");
require("@openzeppelin/hardhat-upgrades");
const path = require("path");
const fs = require("fs");
const { task } = require("hardhat/config");

/** @type import('hardhat/config').HardhatUserConfig */
module.exports = {
  solidity: {
    version: "0.8.27",
    settings: {
      optimizer: {
        enabled: true,
        runs: 200,
      },
      viaIR: true,
    },
    allowUnlimitedContractSize: true,
  },
  networks: {
    dev: {
      url: "http://localhost:8545",
      chainId: 1337,
      gasPrice: 0,
      maxFeePerGas: 0,
      maxPriorityFeePerGas: 0,
      accounts: [
        "0x290d20a9b7f3b5fd3a840f28dba6f8a696f6c767e66801130e809b4ff86f1cfe",
      ],
    },
  }
};

// 아티팩트 생성 유틸리티
function generateArtifactFiles(artifactPath) {
  const artifact = require(artifactPath);
  const contractName = path.basename(artifactPath, ".json");
  const outputDir = path.dirname(artifactPath);

  // ABI 파일 생성
  fs.writeFileSync(
    path.join(outputDir, `${contractName}.abi`),
    JSON.stringify(artifact.abi, null, 2)
  );

  // Bytecode 파일 생성
  fs.writeFileSync(
    path.join(outputDir, `${contractName}.bin`),
    artifact.bytecode.replace("0x", "")
  );
}

task("compile").setAction(async (_, { artifacts }, runSuper) => {
  await runSuper();
  const artifactPaths = await artifacts.getArtifactPaths();
  artifactPaths.forEach(generateArtifactFiles);
});
